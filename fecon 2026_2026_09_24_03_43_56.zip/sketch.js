/* =====================================================
   BLUETRIP — SCRIPT.JS
   Passaporte Emocional do Turismo Azul
===================================================== */


/* =====================================================
   LOCAL STORAGE
===================================================== */

const STORAGE_MEMORIES = "bluetrip_memories";
const STORAGE_USERS = "bluetrip_users";
const STORAGE_CURRENT = "bluetrip_current";


/* =====================================================
   VARIÁVEIS
===================================================== */

let currentUser = null;
let memories = [];
let users = [];
let currentPage = "login";
let searchTerm = "";
let selectedCity = null;


/* =====================================================
   DESTINOS
===================================================== */

const cities = [

  {
    name: "Matinhos",
    emoji: "🏖️",
    description:
      "Praias, cultura e experiências no litoral paranaense."
  },

  {
    name: "Guaratuba",
    emoji: "🌊",
    description:
      "Natureza, mar e paisagens do litoral."
  },

  {
    name: "Paranaguá",
    emoji: "⚓",
    description:
      "História, cultura e conexão com o oceano."
  },

  {
    name: "Ilha do Mel",
    emoji: "🏝️",
    description:
      "Natureza, trilhas e turismo sustentável."
  },

  {
    name: "Pontal do Paraná",
    emoji: "🌴",
    description:
      "Praias e experiências próximas ao mar."
  },

  {
    name: "Morretes",
    emoji: "⛰️",
    description:
      "Serra, cultura e patrimônio paranaense."
  }

];


/* =====================================================
   INICIALIZAÇÃO
===================================================== */

document.addEventListener(
  "DOMContentLoaded",
  () => {

    carregarDados();

    if (currentUser) {
      currentPage = "home";
    }

    render();

  }
);


/* =====================================================
   CARREGAR DADOS
===================================================== */

function carregarDados() {

  try {

    memories =
      JSON.parse(
        localStorage.getItem(
          STORAGE_MEMORIES
        )
      ) || [];


    users =
      JSON.parse(
        localStorage.getItem(
          STORAGE_USERS
        )
      ) || [];


    currentUser =
      JSON.parse(
        localStorage.getItem(
          STORAGE_CURRENT
        )
      ) || null;


  } catch (error) {

    memories = [];
    users = [];
    currentUser = null;

  }

}


/* =====================================================
   SALVAR DADOS
===================================================== */

function salvarDados() {

  localStorage.setItem(
    STORAGE_MEMORIES,
    JSON.stringify(memories)
  );


  localStorage.setItem(
    STORAGE_USERS,
    JSON.stringify(users)
  );


  if (currentUser) {

    localStorage.setItem(
      STORAGE_CURRENT,
      JSON.stringify(currentUser)
    );

  } else {

    localStorage.removeItem(
      STORAGE_CURRENT
    );

  }

}


/* =====================================================
   RENDER PRINCIPAL
===================================================== */

function render() {

  const app =
    document.getElementById("app");


  if (!app) return;


  /* USUÁRIO NÃO LOGADO */

  if (!currentUser) {

    if (currentPage === "signup") {

      app.innerHTML =
        signupPage();

      eventosCadastro();

    } else {

      app.innerHTML =
        loginPage();

      eventosLogin();

    }

    return;
  }


  /* USUÁRIO LOGADO */

  app.innerHTML = `

    ${navbar()}

    <main class="fade-in">

      ${paginaAtual()}

    </main>

    ${footer()}

  `;


  eventosAplicacao();

}


/* =====================================================
   LOGIN
===================================================== */

function loginPage() {

  return `

    <div class="login-page">

      <div class="login-box">

        <div class="logo-login">

          <div class="logo-icon">
            🌊
          </div>

          <h1>
            BlueTrip
          </h1>

          <p>
            Passaporte Emocional do
            Turismo Azul
          </p>

        </div>


        <h2>
          Entrar
        </h2>


        <form id="loginForm">

          <div class="form-group">

            <label>
              E-mail
            </label>

            <input
              type="email"
              id="loginEmail"
              placeholder="seu@email.com"
              required
            >

          </div>


          <div class="form-group">

            <label>
              Senha
            </label>

            <input
              type="password"
              id="loginPassword"
              placeholder="Sua senha"
              required
            >

          </div>


          <button
            class="btn btn-primary"
            type="submit"
          >
            Entrar no BlueTrip
          </button>

        </form>


        <div class="login-link">

          Ainda não tem conta?

          <button id="goSignup">
            Criar conta
          </button>

        </div>

      </div>

    </div>

  `;

}


/* =====================================================
   CADASTRO
===================================================== */

function signupPage() {

  return `

    <div class="login-page">

      <div class="login-box">

        <div class="logo-login">

          <div class="logo-icon">
            🌊
          </div>

          <h1>
            BlueTrip
          </h1>

          <p>
            Crie seu passaporte de memórias
          </p>

        </div>


        <h2>
          Criar conta
        </h2>


        <form id="signupForm">

          <div class="form-group">

            <label>
              Nome
            </label>

            <input
              type="text"
              id="signupName"
              placeholder="Seu nome"
              required
            >

          </div>


          <div class="form-group">

            <label>
              Nome de usuário
            </label>

            <input
              type="text"
              id="signupUsername"
              placeholder="@seuusuario"
              required
            >

          </div>


          <div class="form-group">

            <label>
              E-mail
            </label>

            <input
              type="email"
              id="signupEmail"
              placeholder="seu@email.com"
              required
            >

          </div>


          <div class="form-group">

            <label>
              Senha
            </label>

            <input
              type="password"
              id="signupPassword"
              placeholder="Crie uma senha"
              required
            >

          </div>


        


          <button
            class="btn btn-primary"
            type="submit"
          >
            Criar minha conta
          </button>

        </form>


        <div class="login-link">

          Já possui uma conta?

          <button id="goLogin">
            Entrar
          </button>

        </div>

      </div>

    </div>

  `;

}


/* =====================================================
   NAVBAR
===================================================== */

function navbar() {

  const pages = [

    ["home", "🏠", "Início"],
    ["map", "🗺️", "Mapa"],
    ["create", "➕", "Memória"],
    ["feed", "📸", "Feed"],
    ["profile", "👤", "Perfil"],
    ["passport", "🎫", "Passaporte"],
    ["blue", "🌊", "Turismo Azul"]

  ];


  return `

    <nav class="navbar">

      <div class="logo">

        <span>
          🌊
        </span>

        BlueTrip

      </div>


      <div class="nav-links">

        ${

          pages.map(page => `

            <button
              class="${
                currentPage === page[0]
                  ? "active"
                  : ""
              }"
              data-page="${page[0]}"
            >

              ${page[1]}
              ${page[2]}

            </button>

          `).join("")

        }


        <button
          class="logout"
          id="logoutBtn"
        >

          🚪 Sair

        </button>

      </div>

    </nav>

  `;

}


/* =====================================================
   PÁGINA ATUAL
===================================================== */

function paginaAtual() {

  switch (currentPage) {

    case "home":
      return homePage();

    case "create":
      return createPage();

    case "feed":
      return feedPage();

    case "map":
      return mapPage();

    case "profile":
      return profilePage();

    case "passport":
      return passportPage();

    case "blue":
      return bluePage();

    default:
      return homePage();

  }

}


/* =====================================================
   HOME
===================================================== */

function homePage() {

  return `

    <section class="hero">

      <div class="hero-content">

        <div>

          <h1>
            Viaje.<br>
            Sinta.<br>
            Lembre.
          </h1>


          <p>

            O BlueTrip é um espaço para
            registrar experiências, emoções
            e memórias vividas no litoral
            paranaense, conectando turismo,
            cultura oceânica e sustentabilidade.

          </p>


          <div class="hero-buttons">

            <button
              class="btn btn-secondary"
              data-page="create"
            >

              📸 Criar memória

            </button>


            <button
              class="btn btn-secondary"
              data-page="passport"
            >

              🎫 Ver meu passaporte

            </button>

          </div>

        </div>


        <div class="hero-card">

          <div class="big-icon">
            🌊
          </div>


          <h2>

            Meu litoral,<br>
            minhas memórias.

          </h2>


          <p>

            Cada experiência pode se
            transformar em uma lembrança.

          </p>

        </div>

      </div>

    </section>


    <section class="section">

      <div class="container">

        <div class="section-title">

          <h2>
            Como funciona?
          </h2>

          <p>
            Transforme suas experiências
            em memórias.
          </p>

        </div>


        <div class="cards-grid">


          <div class="card">

            <div class="card-icon">
              📸
            </div>

            <h3>
              Registre
            </h3>

            <p>

              Adicione fotos e conte o que
              você viveu durante sua viagem.

            </p>

          </div>


          <div class="card">

            <div class="card-icon">
              💙
            </div>

            <h3>
              Sinta
            </h3>

            <p>

              Escolha a emoção que representa
              aquele momento.

            </p>

          </div>


          <div class="card">

            <div class="card-icon">
              🌱
            </div>

            <h3>
              Preserve
            </h3>

            <p>

              Conheça práticas de turismo
              sustentável e cultura oceânica.

            </p>

          </div>


        </div>

      </div>

    </section>


    <section class="section">

      <div class="container">

        <div class="section-title">

          <h2>
            Destinos do BlueTrip
          </h2>

          <p>
            Explore diferentes lugares do
            litoral paranaense.
          </p>

        </div>


        <div class="destinations-grid">

          ${

            cities.map(city => `

              <div
                class="destination-card"
                style="
                  background-image:
                  url('${cityImage(city.name)}')
                "
              >

                <div
                  class="destination-overlay"
                >

                  <h3>

                    ${city.emoji}
                    ${city.name}

                  </h3>


                  <p>
                    ${city.description}
                  </p>

                </div>

              </div>

            `).join("")

          }

        </div>

      </div>

    </section>

  `;

}


/* =====================================================
   CRIAR MEMÓRIA
===================================================== */

function createPage() {

  return `

    <section class="section">

      <div class="container">

        <div class="section-title">

          <h2>
            📸 Nova memória
          </h2>

          <p>

            Registre uma experiência especial
            do litoral paranaense.

          </p>

        </div>


        <div class="create-box">

          <form id="memoryForm">


            <div class="form-group">

              <label>
                Foto da memória
              </label>

              <input
                type="file"
                id="memoryPhoto"
                accept="image/*"
                required
              >


              <img
                id="photoPreview"
                class="photo-preview"
                alt="Prévia da foto"
              >

            </div>


            <div class="form-group">

              <label>
                Título da memória
              </label>

              <input
                type="text"
                id="memoryTitle"
                placeholder="Ex.: Um dia inesquecível em Matinhos"
                required
              >

            </div>


            <div class="form-group">

              <label>
                Destino
              </label>

              <select
                id="memoryCity"
                required
              >

                <option value="">
                  Selecione o destino
                </option>

                ${

                  cities.map(city => `

                    <option
                      value="${city.name}"
                    >
                      ${city.name}
                    </option>

                  `).join("")

                }

              </select>

            </div>


            <div class="form-group">

              <label>
                Data da experiência
              </label>

              <input
                type="date"
                id="memoryDate"
                required
              >

            </div>


            <div class="form-group">

              <label>
                Como você se sentiu?
              </label>

              <select
                id="memoryEmotion"
                required
              >

                <option value="">
                  Escolha uma emoção
                </option>

                <option>
                  😊 Feliz
                </option>

                <option>
                  😍 Encantado(a)
                </option>

                <option>
                  😌 Tranquilo(a)
                </option>

                <option>
                  🤩 Animado(a)
                </option>

                <option>
                  🥰 Grato(a)
                </option>

                <option>
                  🌊 Em paz
                </option>

                <option>
                  ✨ Inspirado(a)
                </option>

              </select>

            </div>


            <div class="form-group">

              <label>
                Conte sua experiência
              </label>

              <textarea
                id="memoryText"
                placeholder="Conte o que tornou esse momento especial..."
                required
              ></textarea>

            </div>


            <button
              class="btn btn-primary"
              type="submit"
            >

              🌊 Guardar no meu passaporte

            </button>


          </form>

        </div>

      </div>

    </section>

  `;

}


/* =====================================================
   FEED
===================================================== */

function feedPage() {

  return `

    <section class="section">

      <div class="container">

        <div class="section-title">

          <h2>
            📸 Memórias do BlueTrip
          </h2>

          <p>

            As experiências compartilhadas
            pelos viajantes.

          </p>

        </div>


        <div class="search-box">

          <input
            type="text"
            id="searchInput"
            placeholder="
              🔎 Buscar por destino,
              título, emoção...
            "
            value="${escapeHTML(searchTerm)}"
          >

        </div>


        <div id="memoryList">

          ${renderMemoryList()}

        </div>

      </div>

    </section>

  `;

}


/* =====================================================
   LISTAR MEMÓRIAS
===================================================== */

function renderMemoryList() {

  let list = [...memories];


  if (searchTerm.trim()) {

    const term =
      searchTerm.toLowerCase();


    list = list.filter(memory => {

      const content = `

        ${memory.title || ""}

        ${memory.city || ""}

        ${memory.text || ""}

        ${memory.emotion || ""}

        ${memory.user || ""}

      `.toLowerCase();


      return content.includes(term);

    });

  }


  list.sort(

    (a, b) =>
      (b.createdAt || 0) -
      (a.createdAt || 0)

  );


  if (!list.length) {

    return `

      <div class="empty-state">

        <div class="empty-icon">
          🌊
        </div>


        <h3>
          Ainda não existem memórias
        </h3>


        <p>

          ${

            searchTerm

              ? "Nenhuma memória corresponde à sua busca."

              : "Seja a primeira pessoa a registrar uma experiência!"

          }

        </p>


        ${

          !searchTerm

            ? `

              <button
                class="btn btn-primary"
                data-page="create"
              >

                📸 Criar primeira memória

              </button>

            `

            : ""

        }

      </div>

    `;

  }


  return `

    <div class="memory-grid">

      ${list.map(memoryCard).join("")}

    </div>

  `;

}


/* =====================================================
   CARD DE MEMÓRIA
===================================================== */

function memoryCard(memory) {

  const isOwner =

    currentUser &&
    memory.userEmail ===
    currentUser.email;


  return `

    <article class="memory-card">


      <img
        src="${memory.photo}"
        alt="${escapeHTML(memory.title)}"
        class="memory-photo"
      >


      <div class="memory-body">


        <div class="memory-user">

          👤
          ${escapeHTML(memory.user)}

        </div>


        <div class="memory-city">

          ${escapeHTML(memory.city)}

          •

          ${escapeHTML(memory.date)}

        </div>


        <h3>

          ${escapeHTML(memory.title)}

        </h3>


        <p>

          ${escapeHTML(memory.emotion)}

        </p>


        <p style="margin-top:10px;">

          ${escapeHTML(memory.text)}

        </p>


        <div class="memory-actions">


          <button
            class="action-btn like-btn"
            data-id="${memory.id}"
          >

            ❤️
            ${memory.likes || 0}

          </button>


          <button
            class="action-btn comment-btn"
            data-id="${memory.id}"
          >

            💬
            ${memory.comments || 0}

          </button>


          <button
            class="action-btn map-memory-btn"
            data-city="${escapeHTML(memory.city)}"
          >

            🗺️ Mapa

          </button>


          ${

            isOwner

              ? `

                <button
                  class="
                    action-btn
                    action-danger
                    delete-btn
                  "
                  data-id="${memory.id}"
                >

                  🗑️ Excluir

                </button>

              `

              : `

                <button
                  class="
                    action-btn
                    action-danger
                    report-btn
                  "
                  data-id="${memory.id}"
                >

                  🚩 Denunciar

                </button>

              `

          }


        </div>

      </div>

    </article>

  `;

}


/* =====================================================
   MAPA
===================================================== */

function mapPage() {

  return `

    <section class="section">

      <div class="container">


        <div class="section-title">

          <h2>
            🗺️ Mapa de experiências
          </h2>

          <p>

            Explore os destinos do BlueTrip.

          </p>

        </div>


        <div class="map-box">


          <div class="map-sea"></div>

          <div class="map-land"></div>


          <div class="map-title">

            🌊 Litoral do Paraná

          </div>


          <div
            class="
              map-pin
              pin-matinhos
            "
          >

            <button
              data-city-map="Matinhos"
            >

              🏖️ Matinhos

            </button>

          </div>


          <div
            class="
              map-pin
              pin-guaratuba
            "
          >

            <button
              data-city-map="Guaratuba"
            >

              🌊 Guaratuba

            </button>

          </div>


          <div
            class="
              map-pin
              pin-paranagua
            "
          >

            <button
              data-city-map="Paranaguá"
            >

              ⚓ Paranaguá

            </button>

          </div>


          <div
            class="
              map-pin
              pin-ilha
            "
          >

            <button
              data-city-map="Ilha do Mel"
            >

              🏝️ Ilha do Mel

            </button>

          </div>


          <div
            class="
              map-pin
              pin-pontal
            "
          >

            <button
              data-city-map="Pontal do Paraná"
            >

              🌴 Pontal

            </button>

          </div>


          <div
            class="
              map-pin
              pin-morretes
            "
          >

            <button
              data-city-map="Morretes"
            >

              ⛰️ Morretes

            </button>

          </div>


        </div>


        <div class="selected-city">

          ${

            selectedCity

              ? cityMemories(selectedCity)

              : `

                <div class="empty-state">

                  <div class="empty-icon">
                    🗺️
                  </div>

                  <h3>
                    Escolha um destino
                  </h3>

                  <p>

                    Clique em um dos pontos
                    do mapa para ver as
                    memórias daquele lugar.

                  </p>

                </div>

              `

          }

        </div>


      </div>

    </section>

  `;

}


/* =====================================================
   MEMÓRIAS DE UMA CIDADE
===================================================== */

function cityMemories(city) {

  const list =

    memories.filter(
      memory =>
        memory.city === city
    );


  return `

    <div class="section-title">

      <h2>
        ${city}
      </h2>

      <p>

        ${list.length}

        ${
          list.length === 1
            ? "memória"
            : "memórias"
        }

        registradas.

      </p>

    </div>


    ${

      list.length

        ? `

          <div class="memory-grid">

            ${list
              .map(memoryCard)
              .join("")
            }

          </div>

        `

        : `

          <div class="empty-state">

            <div class="empty-icon">
              📍
            </div>


            <h3>
              Ainda não há memórias aqui
            </h3>


            <p>

              Seja a primeira pessoa
              a registrar uma experiência
              em ${city}.

            </p>


            <button
              class="btn btn-primary"
              data-page="create"
            >

              📸 Criar memória

            </button>

          </div>

        `

    }

  `;

}


/* =====================================================
   PERFIL
===================================================== */

function profilePage() {

  const ownMemories =

    memories.filter(
      memory =>
        memory.userEmail ===
        currentUser.email
    );


  const visitedCities =

    new Set(
      ownMemories.map(
        memory => memory.city
      )
    ).size;


  const totalLikes =

    ownMemories.reduce(
      (total, memory) =>
        total +
        (memory.likes || 0),
      0
    );



     <section class="section">

      <div class="container">


        <div class="profile-header">


            <h2>

              ${escapeHTML(
                currentUser.name
              )}

            </h2>


            <p>

              @${escapeHTML(
                currentUser.username
              )}

            </p>


            <div class="profile-stats">


              <div class="stat">

                <strong>
                  ${ownMemories.length}
                </strong>

                <span>
                  Memórias
                </span>

              </div>


              <div class="stat">

                <strong>
                  ${visitedCities}
                </strong>

                <span>
                  Destinos
                </span>

              </div>


              <div class="stat">

                <strong>
                  ${totalLikes}
                </strong>

                <span>
                  Curtidas
                </span>

              </div>


            </div>

          </div>

        </div>


        <div
          class="section-title"
          style="margin-top:45px;"
        >

          <h2>
            Minhas memórias
          </h2>

          <p>

            Tudo o que você decidiu
            guardar no seu BlueTrip.

          </p>

        </div>


        ${

          ownMemories.length

            ? `

              <div class="memory-grid">

                ${ownMemories

                  .sort(
                    (a,b) =>
                      (b.createdAt || 0) -
                      (a.createdAt || 0)
                  )

                  .map(memoryCard)

                  .join("")

                }

              </div>

            `

            : `

              <div class="empty-state">

                <div class="empty-icon">
                  📸
                </div>


                <h3>

                  Seu passaporte
                  ainda está vazio

                </h3>


                <p>

                  Registre sua primeira
                  experiência.

                </p>


                <button
                  class="btn btn-primary"
                  data-page="create"
                >

                  Criar memória

                </button>

              </div>

            `

        }


      </div>

    </section>

  `;

}


/* =====================================================
   PASSAPORTE
===================================================== */

function passportPage() {

  return `

    <section class="section">

      <div class="container">


        <div class="section-title">

          <h2>
            🎫 Meu Passaporte Emocional
          </h2>

          <p>

            Cada destino visitado pode
            ganhar um carimbo especial.

          </p>

        </div>


        <div class="passport">


          <div class="passport-header">

            <div>

              <h2>
                BlueTrip
              </h2>

              <p>
                Passaporte Emocional
              </p>

            </div>


            <div>
              🌊
            </div>

          </div>


          <div class="stamps">


            ${

              cities.map(city => {

                const unlocked =

                  memories.some(
                    memory =>

                      memory.userEmail ===
                      currentUser.email &&

                      memory.city ===
                      city.name
                  );


                return `

                  <div
                    class="
                      stamp
                      ${
                        unlocked
                          ? "unlocked"
                          : "locked"
                      }
                    "
                  >


                    <div
                      class="stamp-icon"
                    >

                      ${
                        unlocked
                          ? city.emoji
                          : "🔒"
                      }

                    </div>


                    <strong>

                      ${city.name}

                    </strong>


                    <small>

                      ${
                        unlocked

                          ? "Destino registrado!"

                          : "Ainda não visitado"
                      }

                    </small>


                  </div>

                `;

              }).join("")

            }


          </div>

        </div>

      </div>

    </section>

  `;

}


/* =====================================================
   TURISMO AZUL
===================================================== */

function bluePage() {

  return `

    <section class="section">

      <div class="container">


        <div class="section-title">

          <h2>
            🌊 Turismo Azul
          </h2>

          <p>

            Conhecimento para viajar,
            sentir e preservar.

          </p>

        </div>


        <div class="blue-content">


          <div class="blue-card">

            <h3>
              🌊 Cultura oceânica
            </h3>

            <p>

              A cultura oceânica ajuda
              a entender a relação entre
              as pessoas, o oceano e a
              vida no litoral.

            </p>

          </div>


          <div class="blue-card">

            <h3>
              🌱 Turismo sustentável
            </h3>

            <p>

              Viajar de forma responsável
              significa aproveitar os destinos
              procurando reduzir impactos
              ambientais e valorizar as
              comunidades locais.

            </p>

          </div>


          <div class="blue-card">

            <h3>
              🛶 Cultura caiçara
            </h3>

            <p>

              A cultura caiçara faz parte
              da história e da identidade
              de diferentes comunidades
              do litoral.

            </p>

          </div>


          <div class="blue-card">

            <h3>
              💙 Memórias responsáveis
            </h3>

            <p>

              Uma experiência turística
              também pode gerar consciência
              sobre a importância de cuidar
              dos lugares visitados.

            </p>

          </div>


          <div class="blue-card">

            <h3>
              ♻️ Pequenas atitudes
            </h3>


            <ul>

              <li>
                Não deixar lixo nas praias.
              </li>

              <li>
                Respeitar animais e
                ambientes naturais.
              </li>

              <li>
                Valorizar a cultura local.
              </li>

              <li>
                Evitar desperdícios.
              </li>

              <li>
                Cuidar dos espaços públicos.
              </li>

            </ul>

          </div>


          <div class="blue-card">

            <h3>
              ✨ A ideia do BlueTrip
            </h3>

            <p>

              Transformar experiências
              turísticas em memórias que
              também incentivem conhecimento,
              pertencimento e responsabilidade
              com o litoral.

            </p>

          </div>


        </div>

      </div>

    </section>

  `;

}


/* =====================================================
   FOOTER
===================================================== */

function footer() {

  return `

    <footer>

      <p>
        🌊 <strong>BlueTrip</strong>
      </p>

      <p>
        Passaporte Emocional do Turismo Azul
      </p>

      <small>

        Projeto estudantil sobre turismo,
        experiências, memórias e
        sustentabilidade no litoral
        paranaense.

      </small>

    </footer>

  `;

}


/* =====================================================
   EVENTOS DE LOGIN
===================================================== */

function eventosLogin() {

  const form =
    document.getElementById(
      "loginForm"
    );


  const signup =
    document.getElementById(
      "goSignup"
    );


  if (form) {

    form.addEventListener(
      "submit",
      fazerLogin
    );

  }


  if (signup) {

    signup.addEventListener(
      "click",
      () => {

        currentPage =
          "signup";

        render();

      }
    );

  }

}


/* =====================================================
   LOGIN
===================================================== */

function fazerLogin(event) {

  event.preventDefault();


  const email =

    document
      .getElementById(
        "loginEmail"
      )
      .value
      .trim()
      .toLowerCase();


  const password =

    document
      .getElementById(
        "loginPassword"
      )
      .value;


  const user =

    users.find(
      u =>
        u.email === email &&
        u.password === password
    );


  if (!user) {

    alert(
      "E-mail ou senha incorretos."
    );

    return;

  }


  currentUser = user;

  currentPage = "home";

  salvarDados();

  render();

}


/* =====================================================
   EVENTOS DE CADASTRO
===================================================== */

function eventosCadastro() {

  const form =
    document.getElementById(
      "signupForm"
    );


  const login =
    document.getElementById(
      "goLogin"
    );


  if (form) {

    form.addEventListener(
      "submit",
      fazerCadastro
    );

  }


  if (login) {

    login.addEventListener(
      "click",
      () => {

        currentPage =
          "login";

        render();

      }
    );

  }

}


/* =====================================================
   CADASTRO
===================================================== */

function fazerCadastro(event) {

  event.preventDefault();


  const name =

    document
      .getElementById(
        "signupName"
      )
      .value
      .trim();


  const username =

    document
      .getElementById(
        "signupUsername"
      )
      .value
      .trim()
      .replace(
        /^@/,
        ""
      );


  const email =

    document
      .getElementById(
        "signupEmail"
      )
      .value
      .trim()
      .toLowerCase();


  const password =

    document
      .getElementById(
        "signupPassword"
      )
      .value;


  const photoInput =
    document.getElementById(
      "signupPhoto"
    );


  if (
    users.some(
      user =>
        user.email === email
    )
  ) {

    alert(
      "Este e-mail já está cadastrado."
    );

    return;

  }


  if (
    users.some(
      user =>
        user.username.toLowerCase() ===
        username.toLowerCase()
    )
  ) {

    alert(
      "Este nome de usuário já está em uso."
    );

    return;

  }


  const criarUsuario =
    (photo = "") => {

      const user = {

        id:
          Date.now(),

        name,

        username,

        email,

        password,

        photo

      };


      users.push(user);

      currentUser = user;

      currentPage = "home";

      salvarDados();

      render();

    };


  if (
    photoInput.files &&
    photoInput.files[0]
  ) {

    const reader =
      new FileReader();


    reader.onload = () => {

      criarUsuario(
        reader.result
      );

    };


    reader.readAsDataURL(
      photoInput.files[0]
    );


  } else {

    criarUsuario();

  }

}


/* =====================================================
   EVENTOS DA APLICAÇÃO
===================================================== */

function eventosAplicacao() {


  document
    .querySelectorAll(
      "[data-page]"
    )
    .forEach(button => {

      button.addEventListener(
        "click",
        () => {

          currentPage =
            button.dataset.page;


          render();


          window.scrollTo({
            top: 0,
            behavior: "smooth"
          });

        }
      );

    });


  const logout =
    document.getElementById(
      "logoutBtn"
    );


  if (logout) {

    logout.addEventListener(
      "click",
      () => {

        currentUser = null;

        currentPage = "login";

        selectedCity = null;

        searchTerm = "";

        salvarDados();

        render();

      }
    );

  }


  const photo =
    document.getElementById(
      "memoryPhoto"
    );


  if (photo) {

    photo.addEventListener(
      "change",
      previewFoto
    );

  }


  const memoryForm =
    document.getElementById(
      "memoryForm"
    );


  if (memoryForm) {

    memoryForm.addEventListener(
      "submit",
      criarMemoria
    );

  }


  const search =
    document.getElementById(
      "searchInput"
    );


  if (search) {

    search.addEventListener(
      "input",
      event => {

        searchTerm =
          event.target.value;


        const list =
          document.getElementById(
            "memoryList"
          );


        if (list) {

          list.innerHTML =
            renderMemoryList();

          eventosCards();

        }

      }
    );

  }


  document
    .querySelectorAll(
      "[data-city-map]"
    )
    .forEach(button => {

      button.addEventListener(
        "click",
        () => {

          selectedCity =
            button.dataset.cityMap;

          render();

        }
      );

    });


  eventosCards();

}


/* =====================================================
   EVENTOS DOS CARDS
===================================================== */

function eventosCards() {


  /* CURTIR */

  document
    .querySelectorAll(
      ".like-btn"
    )
    .forEach(button => {

      button.addEventListener(
        "click",
        () => {

          const id =
            Number(
              button.dataset.id
            );


          const memory =
            memories.find(
              item =>
                item.id === id
            );


          if (!memory)
            return;


          memory.likes =
            (memory.likes || 0) + 1;


          salvarDados();

          render();

        }
      );

    });


  /* COMENTAR */

  document
    .querySelectorAll(
      ".comment-btn"
    )
    .forEach(button => {

      button.addEventListener(
        "click",
        () => {

          const id =
            Number(
              button.dataset.id
            );


          const memory =
            memories.find(
              item =>
                item.id === id
            );


          if (!memory)
            return;


          const comment =
            prompt(
              "Escreva um comentário:"
            );


          if (
            comment &&
            comment.trim()
          ) {

            memory.comments =
              (memory.comments || 0) + 1;


            salvarDados();

            render();

          }

        }
      );

    });


  /* EXCLUIR */

  document
    .querySelectorAll(
      ".delete-btn"
    )
    .forEach(button => {

      button.addEventListener(
        "click",
        () => {

          const id =
            Number(
              button.dataset.id
            );


          const confirmed =
            confirm(
              "Deseja realmente excluir esta memória?"
            );


          if (!confirmed)
            return;


          memories =
            memories.filter(
              memory =>
                memory.id !== id
            );


          salvarDados();

          render();

        }
      );

    });


  /* DENUNCIAR */

  document
    .querySelectorAll(
      ".report-btn"
    )
    .forEach(button => {

      button.addEventListener(
        "click",
        () => {

          alert(
            "Obrigado. A memória foi marcada para análise."
          );

        }
      );

    });


  /* IR PARA O MAPA */

  document
    .querySelectorAll(
      ".map-memory-btn"
    )
    .forEach(button => {

      button.addEventListener(
        "click",
        () => {

          selectedCity =
            button.dataset.city;


          currentPage =
            "map";


          render();

        }
      );

    });

}


/* =====================================================
   PREVIEW DA FOTO
===================================================== */

function previewFoto(event) {

  const file =
    event.target.files[0];


  const preview =
    document.getElementById(
      "photoPreview"
    );


  if (
    !file ||
    !preview
  ) return;


  const reader =
    new FileReader();


  reader.onload = () => {

    preview.src =
      reader.result;


    preview.style.display =
      "block";

  };


  reader.readAsDataURL(
    file
  );

}


/* =====================================================
   CRIAR MEMÓRIA
===================================================== */

function criarMemoria(event) {

  event.preventDefault();


  const file =

    document
      .getElementById(
        "memoryPhoto"
      )
      .files[0];


  const title =

    document
      .getElementById(
        "memoryTitle"
      )
      .value
      .trim();


  const city =

    document
      .getElementById(
        "memoryCity"
      )
      .value;


  const date =

    document
      .getElementById(
        "memoryDate"
      )
      .value;


  const emotion =

    document
      .getElementById(
        "memoryEmotion"
      )
      .value;


  const textValue =

    document
      .getElementById(
        "memoryText"
      )
      .value
      .trim();


  if (!file) {

    alert(
      "Escolha uma foto para sua memória."
    );

    return;

  }


  const reader =
    new FileReader();


  reader.onload = () => {


    const memory = {

      id:
        Date.now(),

      title,

      city,

      date:
        new Date(
          date + "T12:00:00"
        ).toLocaleDateString(
          "pt-BR"
        ),

      emotion,

      text:
        textValue,

      photo:
        reader.result,

      user:
        currentUser.name,

      userEmail:
        currentUser.email,

      likes:
        0,

      comments:
        0,

      createdAt:
        Date.now()

    };


    memories.push(
      memory
    );


    salvarDados();


    alert(
      "🌊 Memória adicionada ao seu BlueTrip!"
    );


    currentPage =
      "feed";


    render();

  };


  reader.readAsDataURL(
    file
  );

}


/* =====================================================
   IMAGENS DOS DESTINOS
===================================================== */

function cityImage(city) {

  const images = {


    "Matinhos":

      "https://images.unsplash.com/photo-1507525428034-b723cf961d3e?auto=format&fit=crop&w=1000&q=80",


    "Guaratuba":

      "https://images.unsplash.com/photo-1500534623283-312aade485b7?auto=format&fit=crop&w=1000&q=80",


    "Paranaguá":

      "https://images.unsplash.com/photo-1498307833015-e7b400441eb8?auto=format&fit=crop&w=1000&q=80",


    "Ilha do Mel":

      "https://images.unsplash.com/photo-1501785888041-af3ef285b470?auto=format&fit=crop&w=1000&q=80",


    "Pontal do Paraná":

      "https://images.unsplash.com/photo-1473116763249-2faaef81ccda?auto=format&fit=crop&w=1000&q=80",


    "Morretes":

      "https://images.unsplash.com/photo-1464822759023-fed622ff2c3b?auto=format&fit=crop&w=1000&q=80"

  };


  return images[city] || "";

}


/* =====================================================
   ESCAPE HTML
===================================================== */

function escapeHTML(value) {

  return String(value ?? "")

    .replace(
      /&/g,
      "&amp;"
    )

    .replace(
      /</g,
      "&lt;"
    )

    .replace(
      />/g,
      "&gt;"
    )

    .replace(
      /"/g,
      "&quot;"
    )

    .replace(
      /'/g,
      "&#039;"
    );

}